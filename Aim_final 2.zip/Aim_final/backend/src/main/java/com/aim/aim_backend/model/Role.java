package com.aim.aim_backend.model;

public enum Role {
    USER,
    ADMIN
}


