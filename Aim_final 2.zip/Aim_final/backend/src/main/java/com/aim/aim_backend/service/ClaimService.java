/**
 * Claim Service - Business logic for insurance claim management
 * 
 * This service handles all claim-related operations including:
 * - Claim submission with validation and processing
 * - Claim status management (PENDING/APPROVED/REJECTED)
 * - Claim retrieval for users and administrators
 * - Integration with user authentication system
 * 
 * Key Business Rules:
 * - Claims must be associated with valid users and policies
 * - All claims start with PENDING status
 * - Only administrators can update claim status
 * - Claim amounts are validated against policy coverage
 * - Incident photos are stored as base64 encoded strings
 */

package com.aim.aim_backend.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.aim.aim_backend.model.Claim;
import com.aim.aim_backend.model.User;
import com.aim.aim_backend.repository.ClaimRepository;
import com.aim.aim_backend.repository.UserRepository;

@Service
public class ClaimService {

    private final ClaimRepository claimRepository;
    private final UserRepository userRepository;

    public ClaimService(ClaimRepository claimRepository, UserRepository userRepository) {
        this.claimRepository = claimRepository;
        this.userRepository = userRepository;
    }

    /**
     * Submit a new insurance claim (with user authentication)
     * 
     * This method processes claim submissions from authenticated users:
     * 1. Validates user authentication via email
     * 2. Sets default claim status and payment status
     * 3. Generates unique claim number
     * 4. Saves claim to database
     * 
     * @param claim The claim object with incident details
     * @param userEmail Email of the authenticated user
     * @return Saved claim with generated ID and claim number
     * @throws RuntimeException if user not found or save operation fails
     */
    public Claim submitClaim(Claim claim, String userEmail) {
        // Find user by email (throws exception if not found)
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        
        // Set user ID and default statuses
        claim.setUserId(user.getId());
        claim.setStatus("PENDING");        // All claims start as pending
        claim.setPaymentStatus("RECEIVED");  // Assume payment received for demo
        
        // Ensure timestamp is set for audit trail
        if (claim.getCreatedAt() == null) {
            claim.setCreatedAt(java.time.LocalDateTime.now());
        }
        
        // Generate unique claim number for tracking
        if (claim.getClaimNumber() == null || claim.getClaimNumber().isEmpty()) {
            claim.setClaimNumber("CLM" + System.currentTimeMillis());
        }
        
        System.out.println("Saving claim with auth - Type: " + claim.getClaimType() + ", UserId: " + claim.getUserId());
        
        try {
            return claimRepository.save(claim);
        } catch (Exception e) {
            System.err.println("Error saving claim with auth: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to save claim: " + e.getMessage());
        }
    }

    public List<Claim> getClaimsByUserId(Long userId) {
        if (userId != null) {
            return claimRepository.findByUserId(userId);
        }
        return claimRepository.findAll();
    }

    public List<Claim> getClaimsByUserEmail(String userEmail) {
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        return claimRepository.findByUserId(user.getId());
    }

    public Claim updateClaimStatus(Long id, String status) {
        Claim claim = claimRepository.findById(id).orElseThrow();
        claim.setStatus(status);
        return claimRepository.save(claim);
    }

    public List<Claim> getAllClaims() {
        return claimRepository.findAll();
    }

    public Claim submitClaimWithUserId(Claim claim) {
        // Validate required fields
        if (claim.getUserId() == null) {
            throw new RuntimeException("User ID is required for claim submission");
        }
        if (claim.getPolicyId() == null) {
            throw new RuntimeException("Policy ID is required for claim submission");
        }
        if (claim.getClaimType() == null || claim.getClaimType().trim().isEmpty()) {
            throw new RuntimeException("Claim type is required for claim submission");
        }
        
        // Set default values
        claim.setStatus("PENDING");
        claim.setPaymentStatus("RECEIVED");
        
        // Ensure createdAt is set
        if (claim.getCreatedAt() == null) {
            claim.setCreatedAt(java.time.LocalDateTime.now());
        }
        
        // Generate claim number if not set
        if (claim.getClaimNumber() == null || claim.getClaimNumber().isEmpty()) {
            claim.setClaimNumber("CLM" + System.currentTimeMillis());
        }
        
        System.out.println("Saving claim - Type: " + claim.getClaimType() + ", UserId: " + claim.getUserId() + ", PolicyId: " + claim.getPolicyId());
        System.out.println("Claim details - RequestedAmount: " + claim.getRequestedAmount() + ", EstimatedAmount: " + claim.getEstimatedAmount());
        
        try {
            Claim saved = claimRepository.save(claim);
            System.out.println("Claim saved successfully with ID: " + saved.getId());
            return saved;
        } catch (Exception e) {
            System.err.println("Error saving claim: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to save claim: " + e.getMessage());
        }
    }
}