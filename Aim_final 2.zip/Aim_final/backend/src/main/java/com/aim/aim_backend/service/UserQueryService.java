package com.aim.aim_backend.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.aim.aim_backend.model.User;
import com.aim.aim_backend.model.UserQuery;
import com.aim.aim_backend.repository.UserQueryRepository;
import com.aim.aim_backend.repository.UserRepository;

@Service
public class UserQueryService {

    private final UserQueryRepository userQueryRepository;
    private final UserRepository userRepository;

    public UserQueryService(UserQueryRepository userQueryRepository, UserRepository userRepository) {
        this.userQueryRepository = userQueryRepository;
        this.userRepository = userRepository;
    }

    public UserQuery submitQuery(UserQuery query) {
        query.setStatus("OPEN");
        return userQueryRepository.save(query);
    }

    public UserQuery submitQuery(UserQuery query, String userEmail) {
        if (userEmail != null) {
            User user = userRepository.findByEmail(userEmail).orElseThrow();
            query.setUserId(user.getId());
        }
        query.setStatus("OPEN");
        return userQueryRepository.save(query);
    }

    public List<UserQuery> getQueriesByUserEmail(String userEmail) {
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        return userQueryRepository.findByUserId(user.getId());
    }

    public List<UserQuery> getQueriesByUserId(Long userId) {
        if (userId != null) {
            return userQueryRepository.findByUserId(userId);
        }
        return userQueryRepository.findAll();
    }

    public UserQuery replyToQuery(Long id, String response, String status) {
        UserQuery query = userQueryRepository.findById(id).orElseThrow();
        query.setResponse(response);
        query.setStatus(status);
        return userQueryRepository.save(query);
    }
}