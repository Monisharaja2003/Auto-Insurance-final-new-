package com.aim.aim_backend.web;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aim.aim_backend.model.User;
import com.aim.aim_backend.repository.UserRepository;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/test")
    public ResponseEntity<String> test() {
        return ResponseEntity.ok("UserController is working");
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllUsers() {
        try {
            System.out.println("=== GET ALL USERS DEBUG ===");
            List<User> users = userRepository.findAll();
            System.out.println("Found " + users.size() + " users in database");
            
            List<UserResponse> userResponses = users.stream()
                .map(user -> {
                    System.out.println("Processing user: " + user.getEmail() + ", Role: " + user.getRole());
                    return new UserResponse(
                        user.getId(),
                        user.getName(),
                        user.getEmail(),
                        user.getRole().name(),
                        null
                    );
                })
                .collect(Collectors.toList());
            
            System.out.println("Returning " + userResponses.size() + " user responses");
            return ResponseEntity.ok(userResponses);
        } catch (Exception e) {
            System.err.println("Error in getAllUsers: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }

    @PutMapping("/profile")
    public ResponseEntity<?> updateProfile(@RequestBody UpdateProfileRequest request, Authentication auth) {
        try {
            User user = userRepository.findByEmail(auth.getName()).orElseThrow();
            
            if (request.getName() != null && !request.getName().trim().isEmpty()) {
                user.setName(request.getName().trim());
            }
            
            if (request.getEmail() != null && !request.getEmail().trim().isEmpty()) {
                if (!request.getEmail().equals(user.getEmail()) && 
                    userRepository.existsByEmail(request.getEmail())) {
                    return ResponseEntity.badRequest().body("Email already exists");
                }
                user.setEmail(request.getEmail().trim());
            }
            
            if (request.getPassword() != null && !request.getPassword().trim().isEmpty()) {
                user.setPassword(passwordEncoder.encode(request.getPassword()));
            }
            
            userRepository.save(user);
            return ResponseEntity.ok(new ProfileResponse(user.getId(), user.getName(), user.getEmail(), user.getRole().name()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Update failed: " + e.getMessage());
        }
    }

    public static class UpdateProfileRequest {
        private String name;
        private String email;
        private String password;

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    public static class UserResponse {
        private Long id;
        private String name;
        private String email;
        private String role;
        private java.time.LocalDateTime createdAt;

        public UserResponse(Long id, String name, String email, String role, java.time.LocalDateTime createdAt) {
            this.id = id; this.name = name; this.email = email; this.role = role; this.createdAt = createdAt;
        }
        public Long getId() { return id; }
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getRole() { return role; }
        public java.time.LocalDateTime getCreatedAt() { return createdAt; }
    }

    public static class ProfileResponse {
        private Long id;
        private String name;
        private String email;
        private String role;

        public ProfileResponse(Long id, String name, String email, String role) {
            this.id = id; this.name = name; this.email = email; this.role = role;
        }
        public Long getId() { return id; }
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getRole() { return role; }
    }
}