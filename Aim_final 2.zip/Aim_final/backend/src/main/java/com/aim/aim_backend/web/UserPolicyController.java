package com.aim.aim_backend.web;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aim.aim_backend.model.UserPolicy;
import com.aim.aim_backend.service.UserPolicyService;

@RestController
@RequestMapping("/api/user-policies")
public class UserPolicyController {

    private final UserPolicyService userPolicyService;

    public UserPolicyController(UserPolicyService userPolicyService) {
        this.userPolicyService = userPolicyService;
    }

    @PostMapping
    public ResponseEntity<?> apply(@RequestBody UserPolicy req, org.springframework.security.core.Authentication auth) {
        try {
            System.out.println("Policy application request received");
            System.out.println("Request body: " + req);
            
            String userEmail = auth != null ? auth.getName() : "user@example.com";
            
            System.out.println("Using user email: " + userEmail);
            UserPolicy up = userPolicyService.applyPolicy(userEmail, req);
            System.out.println("Policy application successful: " + up.getId());
            return ResponseEntity.ok(up);
        } catch (Exception e) {
            System.err.println("Policy application error: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<?> myPolicies(org.springframework.security.core.Authentication auth) {
        try {
            String userEmail = auth != null ? auth.getName() : "user@example.com";
            return ResponseEntity.ok(userPolicyService.getUserPolicies(userEmail));
        } catch (Exception e) {
            System.err.println("Get policies error: " + e.getMessage());
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
    
    @GetMapping("/test")
    public ResponseEntity<String> test() {
        System.out.println("Test endpoint called");
        return ResponseEntity.ok("UserPolicy controller is working. Auth disabled.");
    }
}


