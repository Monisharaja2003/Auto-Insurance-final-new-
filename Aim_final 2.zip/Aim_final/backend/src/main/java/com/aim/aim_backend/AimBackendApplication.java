package com.aim.aim_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AimBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(AimBackendApplication.class, args);
    }
}