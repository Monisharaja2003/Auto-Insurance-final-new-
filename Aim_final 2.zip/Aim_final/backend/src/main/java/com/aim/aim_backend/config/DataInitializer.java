package com.aim.aim_backend.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.aim.aim_backend.model.Role;
import com.aim.aim_backend.model.User;
import com.aim.aim_backend.repository.UserRepository;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        // Create default user if not exists
        if (!userRepository.existsByEmail("user@example.com")) {
            User defaultUser = new User();
            defaultUser.setName("Default User");
            defaultUser.setEmail("user@example.com");
            defaultUser.setPassword(passwordEncoder.encode("password"));
            defaultUser.setRole(Role.USER);
            userRepository.save(defaultUser);
            System.out.println("Created default user: user@example.com");
        }
    }
}