/**
 * Authentication Controller - Handles user registration, login, and session management
 * 
 * This REST controller provides endpoints for:
 * - User registration (signup) with role selection (USER/ADMIN)
 * - User authentication (login) with session-based security
 * - Current user information retrieval
 * - Secure logout with session cleanup
 * 
 * Security Features:
 * - Session-based authentication (no JWT tokens in frontend)
 * - Role-based access control
 * - Password encryption using BCrypt
 * - CORS configuration for frontend integration
 * - Input validation and error handling
 */

package com.aim.aim_backend.web;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aim.aim_backend.model.Role;
import com.aim.aim_backend.model.User;
import com.aim.aim_backend.service.AuthService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
 

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    /**
     * User Registration Endpoint
     * Allows new users to create accounts with USER or ADMIN roles
     * 
     * @param request Contains user details (name, email, password, role)
     * @return Success message or error if email already exists
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest request) {
        try {
            String result = authService.register(request);
            return ResponseEntity.status(201).body(result); // HTTP 201 Created
        } catch (Exception ex) {
            return ResponseEntity.status(409).body(ex.getMessage()); // HTTP 409 Conflict (email exists)
        }
    }

    /**
     * Alias endpoint for registration - some clients may expect /signup
     */
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@Valid @RequestBody RegisterRequest request) {
        return register(request);
    }

    /**
     * User Login Endpoint
     * Authenticates users and creates server-side session
     * 
     * @param request Contains email and password
     * @param httpRequest Used to create HTTP session
     * @return User data if login successful, error message if failed
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request, HttpServletRequest httpRequest) {
        try {
            User user = authService.login(request, httpRequest);
            // Return user data without sensitive information (no password)
            return ResponseEntity.ok(new LoginResponse(user.getId(), user.getName(), user.getEmail(), user.getRole().name()));
        } catch (Exception ex) {
            return ResponseEntity.status(401).body(ex.getMessage()); // HTTP 401 Unauthorized
        }
    }

    /**
     * Get Current User Endpoint
     * Returns information about the currently authenticated user
     * Used by frontend to check if user is still logged in
     * 
     * @param auth Spring Security authentication object (automatically injected)
     * @return Current user data
     */
    @GetMapping("/me")
    public ResponseEntity<?> me(org.springframework.security.core.Authentication auth) {
        User user = authService.getCurrentUser(auth.getName());
        return ResponseEntity.ok(new MeResponse(user.getId(), user.getName(), user.getEmail(), user.getRole().name()));
    }

    /**
     * User Logout Endpoint
     * Invalidates server-side session and clears security context
     * 
     * @param request HTTP request containing session to invalidate
     * @return Success message
     */
    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        request.getSession().invalidate();        // Destroy server-side session
        SecurityContextHolder.clearContext();    // Clear Spring Security context
        return ResponseEntity.ok("Logged out successfully");
    }

    public static class RegisterRequest {
        private String name;
        private String email;
        private String password;
        private Role role;

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public Role getRole() { return role; }
        public void setRole(Role role) { this.role = role; }
    }

    public static class LoginRequest {
        private String email;
        private String password;

        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    public static class LoginResponse {
        private Long id;
        private String name;
        private String email;
        private String role;

        public LoginResponse(Long id, String name, String email, String role) {
            this.id = id; this.name = name; this.email = email; this.role = role;
        }
        public Long getId() { return id; }
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getRole() { return role; }
    }

    public static class MeResponse {
        private Long id;
        private String name;
        private String email;
        private String role;

        public MeResponse(Long id, String name, String email, String role) {
            this.id = id; this.name = name; this.email = email; this.role = role;
        }
        public Long getId() { return id; }
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getRole() { return role; }
    }
}


