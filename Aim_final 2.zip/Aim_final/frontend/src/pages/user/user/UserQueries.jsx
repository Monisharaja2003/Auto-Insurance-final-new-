import React, { useEffect, useState } from "react";
import client from "../../../api/client";
import { useAuth } from "../../../context/AuthContext";
import "./UserQueries.css";

const UserQueries = () => {
  const { user } = useAuth();
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ queryText: "" });
  const load = async () => {
    const res = await client.get("/api/queries");
    setList(res.data || []);
  };

  useEffect(() => {
    load();
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const queryData = {
        ...form,
        userId: user?.id
      };
      await client.post("/api/queries", queryData);
      setForm({ queryText: "" });
      alert("Query submitted successfully!");
      await load();
    } catch (error) {
      console.error('Error submitting query:', error);
      alert("Failed to submit query. Please try again.");
    }
  };

  return (
    <div className="user-queries-container">
      <h2 className="user-queries-title">Queries</h2>
      <form onSubmit={submit} className="user-queries-form">
        <div className="user-queries-field">
          <label className="user-queries-label">Query</label>
          <textarea
            className="user-queries-textarea"
            value={form.queryText}
            onChange={(e) => setForm({ queryText: e.target.value })}
            placeholder="Enter your query here..."
            rows={3}
            required
          />
        </div>
        <button type="submit" className="user-queries-button">
          Submit
        </button>
      </form>
      <ul className="user-queries-list">
        {list.map((q) => (
          <li key={q.id} className="user-queries-item">
            <div className="user-queries-query">{q.queryText}</div>
            <div className="user-queries-meta">
              <span className={`user-queries-status ${q.status?.toLowerCase() || 'pending'}`}>
                Status: {q.status || 'OPEN'}
              </span>
            </div>
            {q.response && (
              <div className="user-queries-response">
                <strong>Response:</strong> {q.response}
              </div>
            )}
          </li>
        ))}
      </ul>

    </div>
  );
};

export default UserQueries;
