import React, { useEffect, useState } from "react";
import client from "../../../api/client";
import "./ManageUsers.css";

const ManageUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("All");

  const loadUsers = async () => {
    try {
      setLoading(true);
      const res = await client.get("/api/user/all");

      setUsers(res.data || []);
    } catch (err) {
      console.error("Error loading users:", err);
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const filteredUsers = users.filter(user => {
    if (filter === "All") return true;
    return user.role === filter;
  });

  const userStats = {
    total: users.length,
    users: users.filter(u => u.role === "USER").length,
    admins: users.filter(u => u.role === "ADMIN").length
  };



  if (loading) {
    return (
      <div className="manage-users-container">
        <div className="loading-spinner">Loading users...</div>
      </div>
    );
  }

  return (
    <div className="manage-users-container">
      <div className="manage-users-header">
        <h2>Manage Users</h2>
        <div className="user-stats">
          <div className="stat-card">
            <span className="stat-number">{userStats.total}</span>
            <span className="stat-label">Total Users</span>
          </div>
          <div className="stat-card">
            <span className="stat-number">{userStats.users}</span>
            <span className="stat-label">Users</span>
          </div>
          <div className="stat-card">
            <span className="stat-number">{userStats.admins}</span>
            <span className="stat-label">Admins</span>
          </div>
        </div>
      </div>

      <div className="filter-buttons">
        <button
          className={`filter-btn ${filter === "All" ? "active" : ""}`}
          onClick={() => setFilter("All")}
        >
          All Users
        </button>
        <button
          className={`filter-btn ${filter === "USER" ? "active" : ""}`}
          onClick={() => setFilter("USER")}
        >
          Users
        </button>
        <button
          className={`filter-btn ${filter === "ADMIN" ? "active" : ""}`}
          onClick={() => setFilter("ADMIN")}
        >
          Admins
        </button>
      </div>

      <div className="users-table-container">
        <table className="users-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Joined</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.map((user) => (
              <tr key={user.id}>
                <td>#{user.id}</td>
                <td>{user.name || "N/A"}</td>
                <td>{user.email}</td>
                <td>
                  <span className={`role-badge ${user.role.toLowerCase()}`}>
                    {user.role}
                  </span>
                </td>
                <td>
                  {user.createdAt
                    ? new Date(user.createdAt).toLocaleDateString()
                    : "N/A"
                  }
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {filteredUsers.length === 0 && (
        <div className="no-users">
          <p>No users found for the selected filter.</p>
        </div>
      )}
    </div>
  );
};

export default ManageUsers;