import React, { useState } from "react";
import { Routes, Route, Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import CreatePolicy from "./admin/CreatePolicy";
import ManageClaims from "./admin/ManageClaims";
import AdminQueries from "./admin/AdminQueries";
import ViewPolicies from "./admin/ViewPolicies";
import AdminProfile from "./admin/AdminProfile";

import "./AdminDashboard.css";

const AdminDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const logout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const menuItems = [
    { path: "/admin/create-policy", label: "Create Policy", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/document-plus.svg" },
    { path: "/admin/manage-claims", label: "Manage Claims", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/scale.svg" },
    { path: "/admin/user-queries", label: "User Queries", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/chat-bubble-left-right.svg" },
    { path: "/admin/view-policies", label: "View Policies", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/eye.svg" },

    { path: "/admin/profile", label: "Profile", icon: "https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/user.svg" },
  ];

  return (
    <div className="admin-dashboard">
      <header className="admin-appbar">
        <div className="admin-toolbar">
          <button className="admin-menu-btn" onClick={handleDrawerToggle}>
            ☰
          </button>
          <button className="admin-collapse-btn" onClick={() => setSidebarCollapsed(!sidebarCollapsed)}>
            {sidebarCollapsed ? '→' : '←'}
          </button>
          <div className="admin-title-container">
            <h1 className="admin-title">Admin Dashboard</h1>
            <span className="admin-id-badge">Admin ID: #{user?.id || 'N/A'}</span>
          </div>
          <button className="admin-logout-btn" onClick={logout}>
            Logout
          </button>
        </div>
      </header>

      <div
        className={`admin-drawer-overlay ${mobileOpen ? 'open' : ''}`}
        onClick={handleDrawerToggle}></div>

      <nav className={`admin-drawer ${mobileOpen ? 'open' : ''} ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <ul className="admin-drawer-list">
          {menuItems.map((item) => (
            <li key={item.path} className="admin-drawer-item">
              <Link
                to={item.path}
                className={`admin-drawer-link ${location.pathname === item.path ? 'active' : ''
                  }`}
                onClick={() => {
                  setMobileOpen(false);
                  if (location.pathname === item.path) {
                    setSidebarCollapsed(!sidebarCollapsed);
                  }
                }}
              >
                <img src={item.icon} alt="" className="admin-drawer-icon" />
                <span className="admin-drawer-text">{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      <main className={`admin-main ${sidebarCollapsed ? 'expanded' : ''}`}>
        <Routes>
          <Route path="create-policy" element={<CreatePolicy />} />
          <Route path="manage-claims" element={<ManageClaims />} />
          <Route path="user-queries" element={<AdminQueries />} />
          <Route path="view-policies" element={<ViewPolicies />} />
          <Route path="profile" element={<AdminProfile />} />
          <Route path="*" element={<CreatePolicy />} />
        </Routes>
      </main>
    </div>
  );
};

export default AdminDashboard;
