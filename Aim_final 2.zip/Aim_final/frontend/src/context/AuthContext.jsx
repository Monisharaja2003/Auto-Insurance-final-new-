/**
 * Authentication Context - Manages user authentication state across the application
 * 
 * This context provides:
 * - User authentication state management
 * - Login/logout functionality
 * - Protected route components with role-based access control
 * - Session persistence and validation
 * 
 * Key Features:
 * - JWT-based authentication with HTTP-only cookies
 * - Role-based access control (USER/ADMIN)
 * - Automatic session validation on app load
 * - Secure logout with session cleanup
 */

import React, { createContext, useContext, useEffect, useState } from "react";
import client from "../api/client";
import { Navigate } from "react-router-dom";

// Create authentication context
const AuthContext = createContext(null);

/**
 * AuthProvider Component - Wraps the entire app to provide authentication state
 * Manages user session, login status, and provides auth methods to child components
 */
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);     // Current authenticated user data
  const [loading, setLoading] = useState(true); // Loading state during auth check

  /**
   * Load current user data from backend
   * Called on app initialization to check if user is already logged in
   */
  const load = async () => {
    try {
      const res = await client.get("/api/auth/me"); // Validate current session
      setUser(res.data); // Set user data if session is valid
    } catch {
      setUser(null); // Clear user data if session is invalid
    } finally {
      setLoading(false); // Stop loading regardless of result
    }
  };

  // Check authentication status on component mount
  useEffect(() => {
    // Only load user info on initial app load, not after login
    if (user === null) {
      load();
    } else {
      setLoading(false);
    }
  }, []);

  /**
   * Logout function - Clears user session and redirects to home
   * Calls backend logout endpoint and cleans up local state
   */
  const logout = async () => {
    try {
      await client.post("/api/auth/logout"); // Clear server-side session
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      setUser(null); // Clear local user state
      if (typeof window !== "undefined") {
        window.location.replace("/"); // Redirect to home page
      }
    }
  };

  // Context value provided to all child components
  const value = { user, setUser, reload: load, logout };
  
  return (
    <AuthContext.Provider value={value}>
      {loading ? null : children} {/* Don't render children until auth check is complete */}
    </AuthContext.Provider>
  );
};

/**
 * Custom hook to access authentication context
 * Provides easy access to user data and auth methods in any component
 */
export const useAuth = () => useContext(AuthContext);

/**
 * ProtectedRoute Component - Implements role-based access control
 * 
 * @param {React.ReactNode} children - Components to render if access is granted
 * @param {string} role - Required role (USER/ADMIN) to access the route
 * 
 * Access Control Logic:
 * - No user logged in → Redirect to login
 * - Wrong role → Redirect to appropriate dashboard
 * - Correct role → Render children components
 */
export const ProtectedRoute = ({ children, role }) => {
  const { user } = useAuth();
  
  // Redirect to login if no user is authenticated
  if (!user) return <Navigate to="/login" replace />;
  
  // Redirect to appropriate dashboard if user has wrong role
  if (role && user.role !== role)
    return <Navigate to={user.role === "ADMIN" ? "/admin" : "/user"} replace />;
  
  // Render protected content if user has correct role
  return children;
};
